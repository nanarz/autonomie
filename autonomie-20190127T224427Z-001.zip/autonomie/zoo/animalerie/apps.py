from django.apps import AppConfig


class AnimalerieConfig(AppConfig):
    name = 'animalerie'
