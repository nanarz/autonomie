from django.contrib import admin

from .models import Animaux, Equipement

admin.site.register(Animaux)
admin.site.register(Equipement)

